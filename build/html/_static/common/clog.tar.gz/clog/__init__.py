
import log


LOG_DEBUG = log.LOG_DEBUG
